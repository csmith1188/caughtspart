# caughtspart

Here is caughtspart. For this project we have decided to make a system that can be utilized at schools to encourage good behavior.

## Installation
Needs [Node JS](https://nodejs.org/en/download/) and node modules.
 
clone this repository

Go to the directory of the project  
```cd ./caughtspart```

Install needed packages.  
```npm install```

run server to test if project works   
```node server.js```
